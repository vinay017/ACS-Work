
if (typeof (ConfirmIntakeNameSpace) == "undefined") {
    ConfirmIntakeNameSpace = {};
}

ConfirmIntakeNameSpace.Functions = {
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.data.process.addOnStageChange(this.OnStageChange);
    },
    OnStageChange: function (executionContext) {
        var eventArgs = executionContext.getEventArgs();
        var formContext = executionContext.getFormContext();
        var stageName = eventArgs.getStage().getName();
        var activeStageId = formContext.data.process.getActiveStage().getId();
        if (stageName == "In Review") {
            ConfirmGlobalNameSpace.Functions.setPreviousStageId(formContext, activeStageId);
        }
        if (stageName == "Generate Email") {
            if (formContext.getAttribute("cnfm_internalintakeid").getValue() != null) {
                var recordNum = formContext.getAttribute("cnfm_internalintakeid").getValue();
                var entityProperties = {
                    lookUpFieldName: "_cnfm_intakeid_value",
                    entityName: "cnfm_intake",
                    entityIdFieldName: "cnfm_intakeid", entityUniqueNumber: "cnfm_internalintakeid"
                };
                var youthChildEntityProperties = {
                    youthchildEntityName1: "cnfm_docadmission", youthchildEntityFieldName1: "cnfm_docadmissionid",
                    youthchildEntityName2: "cnfm_detentionadmissions", youthchildEntityFieldName2: "cnfm_detentionadmissionsid",
                    youthchildEntityName3: "cnfm_cthplacement", youthchildEntityFieldName3: "cnfm_cthplacementid",
                    youthchildEntityName4: "cnfm_nypdarrest", youthchildEntityFieldName4: "cnfm_nypdarrestid",

                };
                ConfirmGlobalNameSpace.Functions.generateEmail(formContext, recordNum, entityProperties, youthChildEntityProperties);
            }
        }

    }
};