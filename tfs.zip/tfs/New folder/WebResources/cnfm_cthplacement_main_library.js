
if (typeof (ConfirmCTHPlacementNameSpace) == "undefined") {
    ConfirmCTHPlacementNameSpace = {};
}

ConfirmCTHPlacementNameSpace.Functions = {
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.data.process.addOnStageChange(this.OnStageChange);
    },
    OnStageChange: function (executionContext) {
        var eventArgs = executionContext.getEventArgs();
        var formContext = executionContext.getFormContext();
        var stageName = eventArgs.getStage().getName();
        var activeStageId = formContext.data.process.getActiveStage().getId();
        if (stageName == "Review") {
            ConfirmGlobalNameSpace.Functions.setPreviousStageId(formContext, activeStageId);
        }
        if (stageName == "Generate Email") {
            if (formContext.getAttribute("cnfm_cthinternalid").getValue() != null) {
                var recordNum = formContext.getAttribute("cnfm_cthinternalid").getValue();
                var entityProperties = {
                    lookUpFieldName: "_cnfm_cthplacementid_value",
                    entityName: "cnfm_cthplacement",
                    entityIdFieldName: "cnfm_cthplacementid", entityUniqueNumber: "cnfm_cthinternalid"
                };
                var youthChildEntityProperties = {
                    youthchildEntityName1: "cnfm_docadmission", youthchildEntityFieldName1: "cnfm_docadmissionid",
                    youthchildEntityName2: "cnfm_detentionadmissions", youthchildEntityFieldName2: "cnfm_detentionadmissionsid",
                    youthchildEntityName3: "cnfm_nypdarrest", youthchildEntityFieldName3: "cnfm_nypdarrestid",
                    youthchildEntityName4: "cnfm_intake", youthchildEntityFieldName4: "cnfm_intakeid",

                };
                ConfirmGlobalNameSpace.Functions.generateEmail(formContext, recordNum, entityProperties, youthChildEntityProperties);
            }
        }

    }
};