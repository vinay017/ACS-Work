if (typeof (ConfirmGlobalNameSpace) == "undefined") {
    ConfirmGlobalNameSpace = {};
}

ConfirmGlobalNameSpace.Functions = {
    setConcatenatedCaseType: function (formContext) {
        //Read Case Type and set it as a Comma Seperated Value
        if (formContext.getAttribute("cnfm_casetype").getText() != null) {
            var caseType = formContext.getAttribute("cnfm_casetype").getText();
            var concatenatedCaseType = "";
            for (i = 0; i < caseType.length; i++) {
                concatenatedCaseType += caseType[i] + ",";
            }
            formContext.getAttribute("cnfm_delimitedcasetype").setValue(concatenatedCaseType);
        }
    },
    generateEmail: function (formContext, recordNum, entityProperties, youthChildEntityProperties) {
        ConfirmEmailGenerationNameSpace.Functions.matchCriteriaGenerateEmail(formContext, recordNum, entityProperties, youthChildEntityProperties)
    },
    setPreviousStageId: function (formContext, activeStageId) {
        formContext.getAttribute("cnfm_previousstageid").setValue(activeStageId);
        formContext.data.save();
    }
};

//Generate Email NameSpace
if (typeof (ConfirmEmailGenerationNameSpace) == "undefined") {
    ConfirmEmailGenerationNameSpace = {};
}
ConfirmEmailGenerationNameSpace.Functions = {
    matchCriteriaGenerateEmail: function (formContext, recordNum, entityProperties, youthChildEntityProperties) {

        //Declarations
        var alertStrings;
        var alertOptions = { height: 120, width: 260 };
        //Validations
        var caseType = "";
        var validationMessage = "Are you sure you want to proceed to the next Stage? \n\n";
        var alertOptions = { height: 120, width: 260 };
        var partyListArray = new Array();
        var recordId = formContext.data.entity.getId().slice(1, -1);
        Xrm.WebApi.retrieveMultipleRecords("cnfm_casetypes", "?$select=_cnfm_assignedstaff_value,cnfm_casetype,cnfm_name&$filter=(" + entityProperties.lookUpFieldName + " eq " + recordId + ")&$expand=cnfm_assignedstaff($select=cnfm_email)").then(
            function success(casetypesresults) {
                //This block of code queries casetypes  
                //checks for �Assigned Staff and Assigned Staff�s Email� � If either are null it prompts the user so.
                if (casetypesresults.entities.length > 0) {
                    for (var i = 0; i < casetypesresults.entities.length; i++) {
                        if (casetypesresults.entities[i].cnfm_assignedstaff == null
                            || (casetypesresults.entities[i].cnfm_assignedstaff != null && casetypesresults.entities[i].cnfm_assignedstaff.cnfm_email == null)) {
                            caseType += casetypesresults.entities[i]["cnfm_casetype@OData.Community.Display.V1.FormattedValue"] + ",";
                        }

                    }
                    if (caseType != "") {
                        validationMessage += "The Following Case Types " + caseType + " have no assigned staff or is/are missing an Email \n\n\n *Email may not be generated or may have fewer receipients";
                    }

                }
                else {
                    validationMessage += "There are no Case Types attached to this record. \n\n *Please try again after adding Case Types";
                }

                //Confirm Prompt
                var confirmStrings = { text: validationMessage, title: "Notification Confirmation" };
                var confirmOptions = { height: 200, width: 450 };
                Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                    function (success) {
                        if (success.confirmed) {
                            var stateCode = formContext.getAttribute("statecode").getValue();
                            var youthId = formContext.getAttribute("cnfm_youthid").getValue();

                            formContext.getAttribute("cnfm_sendemail").setValue(true); //Set Send Email flag to trigger workflow which sends email
                            if (stateCode == 1) {
                                formContext.getAttribute("statecode").setValue(0); //activate if Inactive
                            }
                            formContext.data.save();

                            var youthCPData =
                            {
                                "statecode": 0,
                            }
                            //activate youth, Connections Case, promis and courtcase (No check if youth/cp is inactive to avoid 2 additional retrieves)
                            Xrm.WebApi.updateRecord("cnfm_youth", youthId[0].id, youthCPData);
                            Xrm.WebApi.retrieveMultipleRecords("cnfm_connectionscase", "?$select=cnfm_connectionscaseid&$filter=(_cnfm_youthid_value eq " + youthId[0].id.slice(1, -1) + ")").then(
                                function (activateConnectionCase) {
                                    if (activateConnectionCase.entities.length > 0) {
                                        for (var i = 0; i < activateConnectionCase.entities.length; i++) {
                                            Xrm.WebApi.updateRecord("cnfm_connectionscase", activateConnectionCase.entities[i].cnfm_connectionscaseid, youthCPData);
                                        }
                                    }
                                });
                            //Check for any duplicate records and deactivate the record and it's corresponding youth record
                            Xrm.WebApi.retrieveMultipleRecords(entityProperties.entityName, "?$select=" + entityProperties.entityIdFieldName + ",_cnfm_youthid_value&$filter=(" + entityProperties.entityUniqueNumber + " eq " + "'" + recordNum + "')" + "and (" + entityProperties.entityIdFieldName + " ne " + recordId + ")").then(
                                function success(result) {
                                    for (var i = 0; i < result.entities.length; i++) {
                                        var data =
                                        {
                                            "statecode": 1,
                                            "cnfm_sendemail": false,
                                        }

                                        //Deactivate the other record as it doesn't qualify for the match criteria
                                        if (result.entities[i][entityProperties.entityIdFieldName] != undefined) {
                                            Xrm.WebApi.updateRecord(entityProperties.entityName, result.entities[i][entityProperties.entityIdFieldName], data);
                                        }

                                        var inactiveYouthId = result.entities[i]._cnfm_youthid_value;
                                        //var slicedInactiveYouthId = result.entities[i]._cnfm_youthid_value.slice(1, -1);
                                        var deactivatedArrestId = result.entities[i][entityProperties.entityIdFieldName];
                                        var deactivateRecord =
                                        {
                                            "statecode": 1,
                                        }
                                        //Deactivate the youth record only if it is not associated to any of the active arrests as this could be a valid youth from an existing arrest. 
                                        //The same is the case for DOC, Detentions, CTH and Intake. The code does a nested query for each of thes etnties by checking for any valid active recors and if any found would not deactivate the Youth record.
                                        Xrm.WebApi.retrieveMultipleRecords(entityProperties.entityName, "?$select=" + entityProperties.entityIdFieldName + "&$filter=(_cnfm_youthid_value eq " + inactiveYouthId + ")" + "and (" + entityProperties.entityIdFieldName + " ne " + deactivatedArrestId + ")").then(
                                            function (inactiveArrests) {
                                                if (inactiveArrests.entities.length == 0) {
                                                    Xrm.WebApi.retrieveMultipleRecords(youthChildEntityProperties.youthchildEntityName1, "?$select=" + youthChildEntityProperties.youthchildEntityFieldName1 + "&$filter=(_cnfm_youthid_value eq " + inactiveYouthId + ")" + "and (statecode eq 0)").then(
                                                        function (activeEntityResults1) {
                                                            if (activeEntityResults1.entities.length == 0) {
                                                                Xrm.WebApi.retrieveMultipleRecords(youthChildEntityProperties.youthchildEntityName2, "?$select=" + youthChildEntityProperties.youthchildEntityFieldName2 + "&$filter=(_cnfm_youthid_value eq " + inactiveYouthId + ")" + "and (statecode eq 0)").then(
                                                                    function (activeEntityResults2) {
                                                                        if (activeEntityResults2.entities.length == 0) {
                                                                            Xrm.WebApi.retrieveMultipleRecords(youthChildEntityProperties.youthchildEntityName3, "?$select=" + youthChildEntityProperties.youthchildEntityFieldName3 + "&$filter=(_cnfm_youthid_value eq " + inactiveYouthId + ")" + "and (statecode eq 0)").then(
                                                                                function (activeEntityResults3) {
                                                                                    if (activeEntityResults3.entities.length == 0) {
                                                                                        Xrm.WebApi.retrieveMultipleRecords(youthChildEntityProperties.youthchildEntityName4, "?$select=" + youthChildEntityProperties.youthchildEntityFieldName4 + "&$filter=(_cnfm_youthid_value eq " + inactiveYouthId + ")" + "and (statecode eq 0)").then(
                                                                                            function (activeEntityResults4) {
                                                                                                if (activeEntityResults4.entities.length == 0) {
                                                                                                    Xrm.WebApi.updateRecord("cnfm_youth", inactiveYouthId, deactivateRecord);
                                                                                                    Xrm.WebApi.retrieveMultipleRecords("cnfm_connectionscase", "?$select=cnfm_connectionscaseid&$filter=(_cnfm_youthid_value eq " + inactiveYouthId + ")").then(
                                                                                                        function (deactivateConnectionCase) {
                                                                                                            if (deactivateConnectionCase.entities.length > 0) {
                                                                                                                for (var i = 0; i < deactivateConnectionCase.entities.length; i++) {
                                                                                                                    Xrm.WebApi.updateRecord("cnfm_connectionscase", deactivateConnectionCase.entities[i].cnfm_connectionscaseid, deactivateRecord);
                                                                                                                }
                                                                                                            }
                                                                                                        });
                                                                                                }
                                                                                            }

                                                                                        );
                                                                                    }
                                                                                }

                                                                            );
                                                                        }
                                                                    }

                                                                );

                                                            }
                                                        }
                                                    );


                                                }
                                            });

                                    }
                                    //This final block prompts an alert message for the user
                                    alertStrings = { text: "An Email is created and ready for preview" };
                                    Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then(
                                        function (alertResult) {
                                            var entityFormOptions = {};
                                            entityFormOptions["entityName"] = entityProperties.entityName;
                                            entityFormOptions["entityId"] = formContext.data.entity.getId();
                                            Xrm.Navigation.openForm(entityFormOptions);
                                        }
                                    );

                                }
                            );

                        }
                        else {
                            formContext.data.process.setActiveStage(formContext.getAttribute("cnfm_previousstageid").getValue());
                        }

                    }

                );
            });
    }
};

