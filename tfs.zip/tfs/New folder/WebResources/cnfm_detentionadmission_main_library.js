if (typeof (ConfirmDetentionAdmissionNameSpace) == "undefined") {
    ConfirmDetentionAdmissionNameSpace = {};
}

ConfirmDetentionAdmissionNameSpace.Functions = {
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.data.process.addOnStageChange(this.OnStageChange);
    },
    OnStageChange: function (executionContext) {
        var eventArgs = executionContext.getEventArgs();
        var formContext = executionContext.getFormContext();
        var stageName = eventArgs.getStage().getName();
        var activeStageId = formContext.data.process.getActiveStage().getId();
        if (stageName == "In Review") {
            ConfirmGlobalNameSpace.Functions.setPreviousStageId(formContext, activeStageId);
        }
        if (stageName == "Generate Email") {
            var recordNum = formContext.getAttribute("cnfm_admissionnumber").getValue();
            var entityProperties = {
                lookUpFieldName: "_cnfm_admissionnumber_value",
                entityName: "cnfm_detentionadmissions",
                entityIdFieldName: "cnfm_detentionadmissionsid", entityUniqueNumber: "cnfm_admissionnumber"
            };
            var youthChildEntityProperties = {
                youthchildEntityName1: "cnfm_docadmission", youthchildEntityFieldName1: "cnfm_docadmissionid",
                youthchildEntityName2: "cnfm_nypdarrest", youthchildEntityFieldName2: "cnfm_nypdarrestid",
                youthchildEntityName3: "cnfm_cthplacement", youthchildEntityFieldName3: "cnfm_cthplacementid",
                youthchildEntityName4: "cnfm_intake", youthchildEntityFieldName4: "cnfm_intakeid",

            };
            ConfirmGlobalNameSpace.Functions.generateEmail(formContext, recordNum, entityProperties, youthChildEntityProperties);
        }

    }
};

