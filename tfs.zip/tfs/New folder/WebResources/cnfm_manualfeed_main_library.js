
if (typeof (ConfirmManualFeedNameSpace) == "undefined") {
    ConfirmManualFeedNameSpace = {};
}

ConfirmManualFeedNameSpace.Functions = {
    OnSave: function (executionContext) {
        var formContext = executionContext.getFormContext();
        this.SetInternalIntakeId(formContext);
    },
    //Set Unique Internal Intake ID to identify multiple records in case of Partial/Multiple Match
    SetInternalIntakeId: function (formContext) {
        if (formContext.getAttribute("cnfm_internalfeedid").getValue() == null) {
            formContext.getAttribute("cnfm_internalfeedid").setValue("I" + Date.now());
        }
    }
};