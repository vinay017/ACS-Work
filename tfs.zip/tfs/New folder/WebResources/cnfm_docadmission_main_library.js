if (typeof (ConfirmDOCAdmissionNameSpace) == "undefined") {
    ConfirmDOCAdmissionNameSpace = {};
}

ConfirmDOCAdmissionNameSpace.Functions = {
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        formContext.data.process.addOnStageChange(this.OnStageChange);
    },
    OnStageChange: function (executionContext) {
        var eventArgs = executionContext.getEventArgs();
        var formContext = executionContext.getFormContext();
        var stageName = eventArgs.getStage().getName();
        var activeStageId = formContext.data.process.getActiveStage().getId();
        if (stageName == "In Review") {
            ConfirmGlobalNameSpace.Functions.setPreviousStageId(formContext, activeStageId);
        }
        if (stageName == "Generate Email") {
            var recordNum = formContext.getAttribute("cnfm_admitid").getValue();
            var entityProperties = {
                lookUpFieldName: "_cnfm_docadmitnumber_value",
                entityName: "cnfm_docadmission",
                entityIdFieldName: "cnfm_docadmissionid", entityUniqueNumber: "cnfm_admitid"
            };
            var youthChildEntityProperties = {
                youthchildEntityName1: "cnfm_nypdarrest", youthchildEntityFieldName1: "cnfm_nypdarrestid",
                youthchildEntityName2: "cnfm_detentionadmissions", youthchildEntityFieldName2: "cnfm_detentionadmissionsid",
                youthchildEntityName3: "cnfm_cthplacement", youthchildEntityFieldName3: "cnfm_cthplacementid",
                youthchildEntityName4: "cnfm_intake", youthchildEntityFieldName4: "cnfm_intakeid",

            };
            ConfirmGlobalNameSpace.Functions.generateEmail(formContext, recordNum, entityProperties, youthChildEntityProperties);
        }

    }
};

