if (typeof (ConfirmEmailNameSpace) == "undefined") {
    ConfirmEmailNameSpace = {};
}

ConfirmEmailNameSpace.Functions = {
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        this.SetReceipients(formContext);
    },

    SetReceipients: function (formContext) {
        var toField = formContext.getAttribute("to").getValue();
        if (toField != null) {
            if (toField.length == 0) {
                var recordId = formContext.data.entity.getId();
                recordId = recordId.slice(1, -1);
                var regarding = formContext.getAttribute("regardingobjectid").getValue();
                if (regarding != null) {
                    var fetchXML = "";
                    if (regarding.length > 0) {
                        if (regarding[0].entityType == "cnfm_nypdarrest") {
                            fetchXML = "<fetch mapping='logical' distinct='true'><entity name='email'><filter><condition attribute='activityid' operator='eq' value='" + recordId + "'/></filter><link-entity name='cnfm_nypdarrest' from='cnfm_nypdarrestid' to='regardingobjectid'><link-entity name='cnfm_casetypes' from='cnfm_arrestnumber' to='cnfm_nypdarrestid'><attribute name='cnfm_assignedstaffsupervisor'/><attribute name='cnfm_assignedstaff'/></link-entity></link-entity></entity></fetch>";
                        }
                        else if (regarding[0].entityType == "cnfm_docadmission") {
                            fetchXML = "<fetch mapping='logical' distinct='true'><entity name='email'><filter><condition attribute='activityid' operator='eq' value='" + recordId + "'/></filter><link-entity name='cnfm_docadmission' from='cnfm_docadmissionid' to='regardingobjectid'><link-entity name='cnfm_casetypes' from='cnfm_docadmitnumber' to='cnfm_docadmissionid'><attribute name='cnfm_assignedstaffsupervisor' /><attribute name='cnfm_assignedstaff' /></link-entity></link-entity></entity></fetch>";
                        }
                        else if (regarding[0].entityType == "cnfm_detentionadmissions") {
                            fetchXML = "<fetch mapping='logical' distinct='true'><entity name='email' ><filter><condition attribute='activityid' operator='eq' value='" + recordId + "' /></filter><link-entity name='cnfm_detentionadmissions' from='cnfm_detentionadmissionsid' to='regardingobjectid' ><link-entity name='cnfm_casetypes' from='cnfm_admissionnumber' to='cnfm_detentionadmissionsid'><attribute name='cnfm_assignedstaffsupervisor' /><attribute name='cnfm_assignedstaff' /></link-entity></link-entity></entity></fetch>";
                        }
                        else if (regarding[0].entityType == "cnfm_cthplacement") {
                            fetchXML = "<fetch mapping='logical' distinct='true'><entity name='email' ><filter><condition attribute='activityid' operator='eq' value='" + recordId + "' /></filter><link-entity name='cnfm_cthplacement' from='cnfm_cthplacementid' to='regardingobjectid' ><link-entity name='cnfm_casetypes' from='cnfm_cthplacementid' to='cnfm_cthplacementid'><attribute name='cnfm_assignedstaffsupervisor' /><attribute name='cnfm_assignedstaff' /></link-entity></link-entity></entity></fetch>";
                        }
                        else if (regarding[0].entityType == "cnfm_intake") {
                            fetchXML = "<fetch mapping='logical' distinct='true'><entity name='email' ><filter><condition attribute='activityid' operator='eq' value='" + recordId + "' /></filter><link-entity name='cnfm_intake' from='cnfm_intakeid' to='regardingobjectid' ><link-entity name='cnfm_casetypes' from='cnfm_intakeid' to='cnfm_intakeid'><attribute name='cnfm_assignedstaffsupervisor' /><attribute name='cnfm_assignedstaff' /></link-entity></link-entity></entity></fetch>";
                        }
                        fetchXML = "?fetchXml=" + encodeURIComponent(fetchXML);
                        var partyListArray = new Array();
                        var partyListArrayCC = new Array();
                        Xrm.WebApi.retrieveMultipleRecords("email", fetchXML).then(
                            function (acsStaffResults) {
                                if (acsStaffResults.entities.length > 0) {
                                    for (var i = 0; i < acsStaffResults.entities.length; i++) {
                                        partyListArray[i] = new Object();
                                        partyListArray[i].id = acsStaffResults.entities[i]["cnfm_casetypes2.cnfm_assignedstaff"];
                                        partyListArray[i].name = acsStaffResults.entities[i]["cnfm_casetypes2.cnfm_assignedstaff@OData.Community.Display.V1.FormattedValue"];
                                        partyListArray[i].entityType = "cnfm_caseplanner";

                                        partyListArrayCC[i] = new Object();
                                        partyListArrayCC[i].id = acsStaffResults.entities[i]["cnfm_casetypes2.cnfm_assignedstaffsupervisor"];
                                        partyListArrayCC[i].name = acsStaffResults.entities[i]["cnfm_casetypes2.cnfm_assignedstaffsupervisor@OData.Community.Display.V1.FormattedValue"];
                                        partyListArrayCC[i].entityType = "cnfm_caseplanner";

                                    }
                                    formContext.getAttribute("to").setValue(partyListArray);
                                    formContext.getAttribute("cc").setValue(partyListArrayCC);
                                    formContext.data.save();
                                }
                            }
                        );
                    }
                }
            }
        }
    }
};