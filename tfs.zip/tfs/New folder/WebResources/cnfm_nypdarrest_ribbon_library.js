function approveArrest(primaryControl) {
    var formContext = primaryControl;
    //Confirm Prompt
    var matchIndicator = formContext.getAttribute("cnfm_matchindicator").getValue();
    var youthFirstName = formContext.getAttribute("cnfm_youthfirstname").getValue();
    var youthLastName = formContext.getAttribute("cnfm_youthlastname").getValue();
    var youthFullName = youthFirstName + " " + youthLastName;
    if (matchIndicator == 330000000) {
        var confirmStrings = { text: "Are your sure you want to notify the Case Planner associated with " + youthFullName, title: "Notification Confirmation" };
    }
    else {
        var confirmStrings = { text: "Are your sure you want to notify the Case Planner associated with " + youthFullName + " \nPlease Note: For multiple similar match results, this action will remove other matched results having similar youth name.", title: "Notification Confirmation" };
    }
    var confirmOptions = { height: 200, width: 450 };
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
        function (success) {
            if (success.confirmed) {
                var recordId = formContext.data.entity.getId();
                var arrestNumber = formContext.getAttribute("cnfm_arrestnumber").getValue();
                var stateCode = formContext.getAttribute("statecode").getValue();
                var youthId = formContext.getAttribute("cnfm_youthid").getValue();
                var cpId = formContext.getAttribute("cnfm_caseplannerid").getValue();

                var youthCPData =
                {
                    "cnfm_isorphan": 330000002,
                }

                Xrm.WebApi.updateRecord("cnfm_youth", youthId[0].id, youthCPData);
                Xrm.WebApi.updateRecord("cnfm_caseplanner", cpId[0].id, youthCPData);

                if (stateCode == 1) {
                    formContext.getAttribute("statecode").setValue(0);
                    formContext.data.save();
                }
                formContext.getAttribute("cnfm_sendemail").setValue(true);

                Xrm.WebApi.retrieveMultipleRecords("cnfm_nypdarrest", "?$select=cnfm_nypdarrestid,_cnfm_youthid_value,_cnfm_caseplannerid_value&$filter=(cnfm_arrestnumber eq " + "'" + arrestNumber + "')" + "and (cnfm_nypdarrestid ne " + "'" + recordId + "')").then(
                    function success(result) {
                        var youthArray = [];
                        var caseplannerArray = [];
                        for (var i = 0; i < result.entities.length; i++) {
                            var data =
                            {
                                "statecode": 1,
                                "cnfm_sendemail": false,
                                "cnfm_checkisorphan": true,
                            }

                            //Deactivate the other records as they don't qualify for the match criteria
                            if (result.entities[i].cnfm_nypdarrestid != undefined) {
                                Xrm.WebApi.updateRecord("cnfm_nypdarrest", result.entities[i].cnfm_nypdarrestid, data);
                            }

                        }
                        var alertStrings = { text: "Case Planner has been notified" };
                        var alertOptions = { height: 120, width: 260 };
                        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                    }
                );

            }
        }
    );
}

function updateIsOrphan(entityName, entityArray) {

    for (i = 0; i < entityArray.length; i++) {
        Xrm.WebApi.retrieveRecord(entityName, entityArray[i], "?$select=cnfm_isorphan").then(
            function success(result) {
                if (result[0].isorphan == 330000000) {

                }
                Xrm.WebApi.updateRecord(entityName, entityId, updateData);
            }
        );
    }
}
