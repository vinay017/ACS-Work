// JavaScript source code
if (typeof (ConfirmNYPDArrestNameSpace) == "undefined") {
    ConfirmNYPDArrestNameSpace = {};
}
ConfirmNYPDArrestNameSpace.Functions = {
    OnLoad: function (executionContext) {
        var formContext = executionContext.getFormContext();
        // setConcatenatedCaseType(formContext);
        //Set Age
        if (formContext.getAttribute("cnfm_age").getValue() == null) {
            var arrestDate = formContext.getAttribute("cnfm_arrestdate").getValue();
            if (arrestDate != null) {
                var dd = arrestDate.getDate();
                var mm = arrestDate.getMonth() + 1; //January is 0!
                var yyyy = arrestDate.getFullYear();
                arrestDate = mm + '/' + dd + '/' + yyyy;

                var dob = formContext.getAttribute("cnfm_youthdob").getValue();
                if (dob != null) {
                    var dobYear = dob.getFullYear();
                    var dobMonth = dob.getMonth() + 1;
                    var dobDay = dob.getDate();
                    var formattedDOB = dobMonth + '/' + dobDay + '/' + dobYear;

                    var diffYear = yyyy - dobYear;
                    var age = diffYear;
                    var diffMonth = mm - dobMonth;
                    var diffDay = dd - dobDay;
                    if (diffMonth < 0) {
                        age = diffYear - 1;
                    }
                    if (diffMonth == 0) {
                        if (diffDay > 0) {
                            age = age + 1;
                        }
                    }
                    formContext.getAttribute("cnfm_age").setValue(age);
                }
            }
        }
        //Add On Stage Event
        formContext.data.process.addOnStageChange(this.OnStageChange);
    },
    OnSave: function (executionContext) {
        var formContext = executionContext.getFormContext();
        ConfirmGlobalNameSpace.Functions(formContext);
    },
    OnStageChange: function (executionContext) {
        var eventArgs = executionContext.getEventArgs();
        var formContext = executionContext.getFormContext();
        var stageName = eventArgs.getStage().getName();
        var activeStageId = formContext.data.process.getActiveStage().getId();
        if (stageName == "In Review") {
            ConfirmGlobalNameSpace.Functions.setPreviousStageId(formContext, activeStageId);
        }
        if (stageName == "Generate Email") {
            var recordNum = formContext.getAttribute("cnfm_arrestnumber").getValue();
            var entityProperties = {
                lookUpFieldName: "_cnfm_arrestnumber_value",
                entityName: "cnfm_nypdarrest",
                entityIdFieldName: "cnfm_nypdarrestid", entityUniqueNumber: "cnfm_arrestnumber"
            };
            var youthChildEntityProperties = {
                youthchildEntityName1: "cnfm_docadmission", youthchildEntityFieldName1: "cnfm_docadmissionid",
                youthchildEntityName2: "cnfm_detentionadmissions", youthchildEntityFieldName2: "cnfm_detentionadmissionsid",
                youthchildEntityName3: "cnfm_cthplacement", youthchildEntityFieldName3: "cnfm_cthplacementid",
                youthchildEntityName4: "cnfm_intake", youthchildEntityFieldName4: "cnfm_intakeid",
                
            };
            ConfirmGlobalNameSpace.Functions.generateEmail(formContext, recordNum, entityProperties, youthChildEntityProperties);
        }

    }
};
